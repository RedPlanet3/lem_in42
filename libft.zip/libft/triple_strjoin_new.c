/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   triple_strjoin_new.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: heula <heula@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/18 16:53:45 by heula             #+#    #+#             */
/*   Updated: 2021/07/18 17:05:26 by heula            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_triple_strjoin(char *s1, char *s2, char *s3)
{
	char	*res;
	char	*tmp;

	if (!s1)
		return (0);
	if (!s2 || !s3)
		return (ft_strdup(s1));
	tmp = ft_strjoin(s1, s2);
	res = ft_strjoin(tmp, s3);
	free(tmp);
	return (res);
}
