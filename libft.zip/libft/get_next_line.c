/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: heula <heula@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/03 22:31:26 by heula             #+#    #+#             */
/*   Updated: 2021/04/14 21:12:45 by heula            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	cleaning(char **trash)
{
	if (!trash)
		return ;
	if (!*trash)
		return ;
	free(*trash);
	*trash = NULL;
}

int	linecut(char **line, char **buf)
{
	char	*clearline;
	size_t	size;
	char	*bufptr;

	clearline = NULL;
	if ((ft_strchr(*line, '\n')) != NULL)
	{
		size = ft_strlen(*line) - ft_strlen(ft_strchr(*line, '\n'));
		clearline = (char *)ft_malloc((size + 1) * sizeof(char));
		ft_memmove(clearline, *line, size);
		clearline[size] = '\0';
		cleaning(line);
		*line = NULL;
		*line = clearline;
		bufptr = ft_strchr(*buf, '\n') + 1;
		bufptr[ft_strlen(bufptr)] = '\0';
		ft_memmove(*buf, bufptr, ft_strlen(bufptr) + 1);
	}
	return (1);
}

char	*bufadd(char **line, char *buf)
{
	size_t	len;
	size_t	i;
	char	*newline;

	newline = NULL;
	i = 0;
	if (*buf)
	{
		len = ft_strlen(*line);
		newline = (char *)ft_malloc((len + ft_strlen(buf) + 1) * sizeof(char));
		ft_memmove(newline, *line, len);
		ft_memmove(&newline[len], buf, ft_strlen(buf) + 1);
		newline[ft_strlen(newline)] = '\0';
		cleaning(line);
		*line = newline;
	}
	return (*line);
}

int	buflinecheck(char **line, char **buf)
{
	char	*bufptr;

	bufptr = NULL;
	*line = (char *)ft_malloc((BUFFER_SIZE + 1) * sizeof(char));
	**line = '\0';
	if (*buf)
	{
		bufptr = *buf;
		if (*bufptr == '\n')
		{
			ft_memmove(bufptr, &bufptr[1], ft_strlen(&bufptr[1]) + 1);
			return (10);
		}
		ft_memmove(*line, bufptr, ft_strlen(bufptr) + 1);
	}
	if (!*buf)
		*buf = (char *)ft_malloc((BUFFER_SIZE + 1) * sizeof(char));
	return (1);
}

int	get_next_line(int fd, char **line)
{
	static char	*buf;
	int			book;

	*line = NULL;
	book = buflinecheck(line, &buf);
	if (book == 10)
		return (1);
	while ((ft_strchr(*line, '\n')) == NULL)
	{
		book = read(fd, buf, BUFFER_SIZE);
		if (book == -1)
		{
			cleaning(line);
			return (-1);
		}
		buf[book] = '\0';
		if ((bufadd(line, buf)) == NULL)
			return (-1);
		if (book == 0)
		{
			cleaning(&buf);
			return (0);
		}
	}
	return (linecut(line, &buf));
}
