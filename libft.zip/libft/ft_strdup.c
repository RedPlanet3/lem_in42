/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: heula <heula@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/09 20:04:38 by heula             #+#    #+#             */
/*   Updated: 2021/06/05 16:28:50 by heula            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s1)
{
	size_t	len;
	char	*buf;

	buf = NULL;
	if (s1)
	{
		len = ft_strlen(s1);
		buf = (char *)ft_malloc(sizeof(const char) * (len + 1));
		buf[len] = '\0';
		while (len--)
			buf[len] = s1[len];
	}
	return (buf);
}
